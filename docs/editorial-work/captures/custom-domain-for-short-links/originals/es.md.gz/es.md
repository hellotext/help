## Enlaces Cortos

<div class="note">
    Nota: El alias de enlace corto es parte de la función <i>Marca Blanca</i>.
    Consulta nuestros <a href="https://www.hellotext.com/precios" class="active" target="_blank">precios</a> para obtener más información.
</div>

Hellotext genera enlaces cortos que se utilizan para hacer tracking de la actividad del cliente después de que hace clic desde un mensaje.

Con los enlaces cortos, puedes saber qué campaña, ruta, misión o conversación del Inbox envió el mensaje al cliente, cuándo hizo clic en el enlace corto y a dónde fue redirigido.

Por defecto, Hellotext genera enlaces cortos utilizando el dominio `hello.link`. Los enlaces cortos se mostrarán en el siguiente formato al enviar a los clientes: `hello.link/XXXXXX`.

El alias de un enlace corto le permite especificar un dominio específico para usar en lugar de `hello.link`.

Ayuda a que tus mensajes sean más personalizados, ya que tus clientes reconocen el dominio y confían automáticamente en el enlace. Esto puede ser útil para fortalecer la confianza en tu marca.

Por ejemplo, si eres dueño del dominio `mydomain.com`, puedes configurar tus enlaces cortos para usar `mydomain.com` en lugar de `hello.link`.

Entonces, cuando se generan enlaces cortos, Hellotext utilizará el dominio que especificó en lugar de `hello.link`.

Los enlaces cortos se mostrarán en el siguiente formato al enviar a los clientes: `mydomain.com/XXXXXX`.

## Configurar el alias en Hellotext

Para configurar el alias, debe ser un administrador o propietario del negocio.

En primer lugar, inicie sesión en su cuenta y vaya a la página de configuración del negocio. Haga clic en _Editar negocio_.

Luego ingrese un nombre de dominio en el campo CNAME y asegúrese de que el CNAME corresponda a un dominio que usted posea.

## Configurar un subdominio

Navega a tu proveedor de DNS y crea un registro CNAME que apunte tu subdominio al dominio predeterminado de tu sitio.

Por ejemplo, si deseas usar el subdominio `shop.mysite.com` para Enlaces Cortos, crea un registro CNAME que apunte `shop.mysite.com` a `hello.link`. 

Para obtener más información sobre cómo crear el registro correcto, consulta la documentación de tu proveedor de DNS.

## Configurar un dominio apex

Para configurar un dominio ápice, como por ejemplo `example.com`, debes configurar un dominio personalizado en la configuración de tu negocio y crear un registro ALIAS o ANAME con tu proveedor de DNS.

Por ejemplo, si en lugar de utilizar el subdominio `shop.mysite.com` para Enlaces Cortos, deseas usar el dominio ápice `mysite.com`, debes crear un registro ALIAS o ANAME que apunte `mysite.com` a `hello.link`.

Para obtener más información sobre cómo crear el registro correcto, consulta la documentación de tu proveedor de DNS.

<div class="note">
    Nota: Los cambios de DNS pueden tardar hasta 24 horas en propagarse.
</div>

Después de configurar el alias en Hellotext, Hellotext comenzará a usar el alias configurado cuando se haya verificado.

## <a id='verification' href='#verification' class='navigator'>Proceso de Verificación</a>

Hellotext intenta verificar el alias haciéndole ping cada 5 minutos.

Una vez que el ping se realiza con éxito, esto significa que el ping ha viajado desde Hellotext hasta tu proveedor de DNS y ha vuelto a Hellotext.

Esto indica que el alias está configurado correctamente y Hellotext comenzará a usar el alias para enlaces cortos en ese momento.

Cuando actualices el alias, Hellotext iniciará nuevamente el proceso de verificación.

## Notas sobre cómo cambiar el alias

Los alias se utilizan en los mensajes enviados a los clientes; después de configurar el alias en un dominio específico, debes tener cuidado al cambiarlo nuevamente.

Si cambias el alias, Hellotext comenzará a usar ese alias inmediatamente después de haberlo verificado.

Sin embargo, los mensajes que se enviaron antes de que se cambiara el alias seguirán usando el alias anterior. Esto significa que cuando cambias el alias, debes configurar redireccionamientos correctos a `hello.link` para el alias anterior, de modo que los clientes aún puedan abrir los enlaces cortos que se les enviaron antes de que se cambiara el alias.

Hellotext no es responsable de enrutar enlaces cortos antiguos al destino correcto, por lo que debes asegurarte de que el alias anterior siga siendo válido.
