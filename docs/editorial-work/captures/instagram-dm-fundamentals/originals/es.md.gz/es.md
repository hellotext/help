Conecta Instagram cuando los clientes descubren tu negocio allí y esperan continuar por mensajes directos. Hellotext puede llevar las conversaciones elegibles de Instagram al Inbox para que el equipo, las misiones, las rutas y los agentes de IA respondan con contexto compartido.

Instagram DM es principalmente un canal conversacional iniciado por el cliente. Funciona distinto a los envíos de campañas por SMS y WhatsApp: que alguien siga tu cuenta o que conozcas su nombre de usuario no permite, por sí solo, iniciar un nuevo mensaje directo.

Para configurar el canal, sigue [Conecta Instagram DM]({% link _integrations/connect-instagram-dm.md %}). Esta guía explica qué ocurre después de conectarlo.

## Para qué sirve mejor Instagram DM

Usa Instagram DM para:

- Consultas sobre productos de personas que exploran tu perfil o contenido de Instagram.
- Conversaciones de soporte que empiezan como mensaje directo.
- Respuestas compatibles a una historia de Instagram.
- Agentes de IA reactivos y misiones reactivas que responden en el canal donde escribió el cliente.
- Rutas que hacen preguntas, recopilan contexto, crean ramas o asignan una conversación activa.
- Respuestas individuales desde el Inbox durante una conversación elegible.

Instagram DM no es actualmente una opción de envío en el creador de campañas. Usa las campañas con sus opciones disponibles de WhatsApp y SMS, e Instagram para conversaciones iniciadas por el cliente y flujos conversacionales elegibles.

## Cómo empiezan las conversaciones de Instagram

Un cliente inicia la conversación en Instagram enviando un mensaje directo o una respuesta compatible a una historia. Después, Hellotext:

1. Recibe la identidad de Instagram y el contenido compatible del mensaje.
2. Encuentra o crea el perfil del cliente correspondiente.
3. Agrega la identidad de Instagram a ese perfil del cliente.
4. Abre o actualiza la conversación privada en el Inbox.
5. Deja la conversación disponible para la persona, la ruta, la misión o el agente de IA que configuraste.

Un seguidor no queda disponible automáticamente para mensajes directos. El cliente primero debe crear una interacción elegible en Instagram para que Hellotext pueda responder por este canal.

Los mensajes enviados directamente desde la cuenta conectada de Instagram también pueden sincronizarse con la conversación de Hellotext, manteniendo el historial del Inbox alineado con la actividad que ocurrió en Instagram.

## Entiende la ventana de mensajería

Meta aplica una ventana estándar de mensajería de 24 horas después de un mensaje elegible del cliente. Cada nuevo mensaje elegible del cliente vuelve a abrir la ventana. Hellotext considera que una conversación de Instagram está disponible para responder mientras esa ventana siga abierta, y Meta controla la elegibilidad final de la entrega.

A diferencia de WhatsApp, Instagram no usa en Hellotext una plantilla de mensaje aprobada para reiniciar una conversación cerrada. Cuando la ventana ya no está disponible, espera a que el cliente vuelva a escribir o continúa por otro canal solo cuando ese cliente sea elegible allí.

No uses otro canal para evitar las reglas de consentimiento o una conversación cerrada en Instagram. Cada destino debe cumplir sus propias reglas de disponibilidad y suscripción.

## Mensajes e interacciones compatibles con Hellotext

Hellotext puede procesar actividad compatible de mensajes directos de Instagram, como:

- Mensajes de texto de hasta 1.000 caracteres.
- Imágenes, videos, audios y otros adjuntos compatibles.
- Mensajes de voz, stickers y respuestas a mensajes anteriores.
- Respuestas compatibles a historias.
- Respuestas rápidas, botones y tarjetas de producto creadas por misiones o flujos de mensajes compatibles.
- Actividad de lectura y reacciones cuando Meta las proporciona.

Los comentarios públicos, menciones en historias y contenido efímero no se tratan como conversaciones normales de Instagram DM en el Inbox. Prueba la interacción exacta que esperas que usen los clientes en lugar de asumir que cada notificación de Instagram se convierte en una conversación.

## Gestiona conversaciones de Instagram en el Inbox

Las conversaciones de Instagram usan el mismo modelo de responsables del Inbox que los demás canales de clientes compatibles. Tu equipo puede:

- Responder desde la conversación activa de Instagram.
- Asignar o reasignar la conversación a una persona o equipo.
- Agregar contexto interno sin enviarlo al cliente.
- Cerrar la conversación cuando no se necesita otra acción.
- Reabrir el trabajo cuando llega un nuevo mensaje elegible del cliente.

El canal activo importa. El contenido disponible en WhatsApp o Webchat puede no tener la misma presentación o compatibilidad en Instagram, así que revisa y prueba la versión de Instagram de la respuesta.

Sigue leyendo: [Resumen de Inbox y conversaciones]({% link _team/inbox-overview.md %}) y [Asigna conversaciones]({% link _team/assigning-conversations.md %}).

## Usa misiones, rutas y agentes de IA

Las misiones reactivas y los agentes de IA pueden configurarse para responder en todos los canales de entrada o específicamente en Instagram DM. Reciben el contexto de la conversación y pueden responder, recomendar productos, recopilar información o derivar la conversación según su configuración.

Para un agente de IA, confirma que:

- Instagram esté incluido entre sus canales de entrada.
- Su conocimiento e instrucciones cubran las preguntas que hacen los clientes allí.
- Su destino de Derivación esté configurado para los casos que no puede resolver.
- Sus respuestas de Instagram hayan sido probadas en el playground y mediante un mensaje directo real.

Las rutas pueden usar pasos de Instagram mientras el cliente y el canal sigan siendo elegibles. Prueba envíos, preguntas, ramas y pasos de asignación, incluyendo qué debería ocurrir cuando la ventana de Instagram se cierre o la integración deje de estar disponible.

Algunas misiones autónomas proactivas pueden considerar Instagram solo cuando el cliente ya tiene una identidad de Instagram disponible y el mensaje es elegible según las reglas de Meta y Hellotext. Habilitar Instagram no hace que todas las oportunidades de una misión se envíen por este canal.

Sigue leyendo: [Derivación de IA al Inbox]({% link _team/ai-handoff-to-inbox.md %}) y [Cómo decide Hellotext si una misión puede enviar]({% link _journeys/how-hellotext-decides-whether-a-playbook-can-send.md %}).

## Perfiles del cliente y consentimiento

Una conversación entrante de Instagram puede agregar una identidad de Instagram a un perfil del cliente. Esa identidad es específica de la cuenta conectada de Instagram y no debería tratarse como número de teléfono, suscripción de WhatsApp o permiso para enviar marketing por otro canal.

Si el mismo cliente existe bajo otro perfil, revisa los datos antes de combinar los perfiles. Conserva la conversación, identificadores, propiedades e historial de compras correctos.

Respeta las solicitudes de baja y bloqueo. Que un cliente escriba por Instagram no otorga permiso ilimitado para futuros mensajes salientes.

Sigue leyendo: [Perfiles de clientes]({% link _audience/customer-profiles.md %}) y [A quién puedo escribirle: consentimiento y estado de suscripción]({% link _audience/consent-and-subscriber-status.md %}).

## Precios y uso

Los mensajes directos de Instagram se incluyen en el cálculo de mensajes que no son SMS de Hellotext. El importe variable se convierte en el cargo de Hellotext solo cuando es mayor que el mínimo del plan, la tarifa por performance y el importe de SMS del período de facturación.

Revisa [Política de uso justo de mensajes]({% link _billing/fair-use-message-policy.md %}) para consultar la tarifa publicada vigente y el cálculo.

## Soluciona un mensaje de Instagram faltante o fallido

Si un mensaje entrante no aparece:

- Confirma que la cuenta profesional correcta de Instagram esté conectada y activa.
- Envía un mensaje directo desde otra cuenta, no desde la cuenta conectada del negocio hacia sí misma.
- Revisa que la interacción sea un DM o respuesta compatible a una historia y no un comentario, mención en historia o contenido efímero.
- Confirma que Hellotext todavía tenga los permisos solicitados de Instagram.
- Revisa si el perfil del cliente o la conversación están bloqueados.

Si una respuesta no se envía:

- Confirma que la ventana de mensajería todavía sea elegible.
- Revisa que la integración y el canal de Instagram estén activos.
- Revisa el motivo exacto del error antes de reintentar.
- Confirma que el contenido y el adjunto sean compatibles y que el texto no supere los 1.000 caracteres.
- Evita reintentos repetidos cuando Meta haya rechazado el destino o estado de la conversación.

Consulta [Por qué no se envió un mensaje]({% link _troubleshooting-deliverability/why-a-message-did-not-send.md %}) para usar el checklist compartido de entrega.

## Checklist para el primer lanzamiento de Instagram

Antes de depender de Instagram DM, confirma que:

1. La cuenta profesional correcta esté conectada y activa.
2. Un DM de prueba cree o actualice el perfil del cliente correcto.
3. La conversación aparezca en el Inbox con la identidad de Instagram correcta.
4. Las personas, equipos, misiones, rutas o agentes de IA reciban la conversación como esperas.
5. El texto, adjuntos, respuestas a historias, botones y tarjetas de productos que planeas usar hayan sido probados.
6. La Derivación llegue a la persona o equipo correcto.
7. Tu equipo entienda la ventana de mensajería y el proceso de reconexión.

## Guías relacionadas

- [Conecta Instagram DM]({% link _integrations/connect-instagram-dm.md %})
- [Resumen de canales de mensajería]({% link _numbers/messaging-overview.md %})
- [Resumen de Inbox y conversaciones]({% link _team/inbox-overview.md %})
- [Derivación de IA al Inbox]({% link _team/ai-handoff-to-inbox.md %})
- [Resumen de misiones y automatización]({% link _journeys/playbooks-overview.md %})
- [Primeros pasos con rutas]({% link _journeys/getting-started-with-journeys.md %})
- [Envía mensajes con la API]({% link _developers/send-messages-with-api.md %})
